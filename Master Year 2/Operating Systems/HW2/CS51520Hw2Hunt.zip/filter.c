/*
   Course: CS 51520
	Name: Marcellus Hunt
	Email: mkhunt@pnw.edu
	Assignment: 2

*/
#include <stdio.h>   // scanf(), fscanf(), fprintf(), fopen()
#include <stdlib.h>  // atoi(), getenv()

int main(int argc, char* argv[])
{   
   //set precision and column VAlUES to default
   // STEP1 AND STEP 2

   int column = 3;
   int precision = 13;
   int width = precision + 5;
   
   //STEP 6 Config file
   //check if config file exists then open
   FILE* config;
   config= fopen("filter.cfg.txt" , "r");
   
   //get both positive numbers from config
   int num1;
   int num2;
   
   //if config file is present
   if(config)
   {
      //read in value
      fscanf(config, "%d %d",&num1, &num2);
      //set column, precision and update width to new values
      column = num2;
      precision = num1;
      width = precision + 5;
      
      //close file
      fclose(config);
   }
   
   //used to read input
   double input;

   //STEP 4 Check for environment variables
   
   //precision variable   
   if (getenv("CS51520_PRECISION"))
   {
      //get enviornment and then use atoi function to convert to int
      char* strprecision;
      strprecision = getenv("CS51520_PRECISION");
      precision = atoi(strprecision);
      width = precision + 5;
   }
 
   //column variable
   if (getenv("CS51520_COLUMNS"))
   {
      //get enviornment and then use atoi function to convert to int
      char * strcolumn;
      strcolumn = getenv("CS51520_COLUMNS");
      column = atoi(strcolumn);
   }
   
   
   //STEP3 & 5 command line argument   
   if (argc >=2)
   {
      //get column number
      column = atoi(argv[1]);
   }
   if(argc>=3)
   {
      //get precision number & update width
      precision = atoi(argv[2]);
      width = precision + 5;
   }
   
   //use counter to keep note of column
   int counter = 0;
   
   while (scanf("%lf ",&input)!= EOF)
   {
      //COLUMN 1
      //print contents of file
      printf("%*.*f  ",width,precision,input);
      
      //increment counter
      counter++;
      
      if(counter==column)
      {
         //start new line & reset counter
         printf("\n");
         counter = 0;
      }
   }
   
   return 0;
}