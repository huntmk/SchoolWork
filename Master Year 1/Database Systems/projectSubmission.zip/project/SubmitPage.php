<!DOCTYPE html>
<?php
	include_once 'includes/connect.php';
?>
<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	<h1 id="header"> Submission Page</h1>
		<div id="great_deals">
			<ul id="naviagtion">
				<li><a href ="./HomePage.php">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>
			
				<p> 
					An email has been sent to 
					<?php
					session_start();
					$sql = "SELECT * FROM Customer WHERE email = '".$_SESSION['email']."'";
					$result = mysqli_query($con,$sql);
					
					while($d= mysqli_fetch_assoc($result))
					{
						echo "Name: " .$d['c_name']. " at Email: " .$d['email']. " Address: " .$d['address']. "<br>";
					}
					
					?>
				</p>
				
			
		</div>
	</body>
</html>