<!DOCTYPE html>
<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	<h1 id="header"> Airlines Website - Acccount Creation </h1>
		<div id="account_creation">
			<ul id="naviagtion">
				<li><a href ="./HomePage.php">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>
			<form method="POST" action ="includes/creation.php">
				<label> Name:
				<input type="text" name="name" id="name">
				</br></br>
				
				<label> Address
				<input type="text" name="address" id="address">
				</br></br>
				
				<label> Username(email):
				<input type="text" name="username" id="username">
				</br></br>
				
				<label>Password:
				<input type="text" name="password" id="password">
				</br></br>
				
				<input type="submit" name="Submit" value="Create">

			</form>	
				
		</div>	
	</body>
</html>	
				