<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	<h1 id="header"> Airlines Website - Select Ticket Quantity</h1>
		<div id="ticket_quantity">
			<ul id="naviagtion">
				<li><a href ="./HomePage.php">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>
		
			<p> Select Ticket Quantity </p>
			<form method="POST" action="includes/ticket.php">
				<input type="number" name="quantity" value="1" min="1" max="10">
				<input type="submit"/>
			</form>

		</div>