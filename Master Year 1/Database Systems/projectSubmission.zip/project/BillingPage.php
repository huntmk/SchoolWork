<!DOCTYPE html>
<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	<h1 id="header"> Billing Page</h1>
		<div id="great_deals">
			<ul id="naviagtion">
				<li><a href ="./HomePage.php">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>
			
			<form method="POST" action ="includes/billing.php">
				<label> Card Number:
				<input type="text" name="cardnum" maxlength="16" />
				</br></br>
				
				<label> Card Month
				<select name='expMonth' id='expireMM'>
					<option value='1'>1-January</option>
					<option value='2'>2-February</option>
					<option value='3'>3-March</option>
					<option value='4'>4-April</option>
					<option value='5'>5-May</option>
					<option value='6'>6-June</option>
					<option value='7'>7-July</option>
					<option value='8'>8-August</option>
					<option value='9'>9-September</option>
					<option value='10'>10-October</option>
					<option value='11'>11-November</option>
					<option value='12'>12-December</option>
				</select> 
				
				<label> Card Year
				<select name='expYear' id='expireYY'>
					<option value='22'>2022</option>
					<option value='23'>2023</option>
					<option value='24'>2024</option>
					<option value='25'>2025</option>
					<option value='26'>2026</option>
					<option value='27'>2027</option>
				</select> 
				
				<input type="submit" >
			</form>
			
		</div>
	</body>
</html>