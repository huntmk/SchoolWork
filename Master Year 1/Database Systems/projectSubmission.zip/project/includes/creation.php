<?php
	include_once 'connect.php';
	if(!empty($_POST['name']) && !empty($_POST['address']) && !empty($_POST['username']) && !empty($_POST['password']) )
	{
		
		$name = $_POST['name'];
		$address = $_POST['address'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		//need to check if email already exists, if so give an error
		$sql = "SELECT email FROM Customer WHERE email = '".$user."'";
		
		$result = mysqli_query($con,$sql);
		
		//if this email exists, output error
		if(mysqli_num_rows($result) == 1)
		{
			header("Location: ../LoginPage.php?this email already exists");
		}
		else
		{
			$insert_sql = "INSERT INTO Customer (c_name,email,address,password)
			VALUES ('$name','$username',
			'$address','$password')";

			mysqli_query($con,$insert_sql);
			
			header("Location: ../LoginPage.php?creation=successful. Now login");		
		}
		
	}
	else
	{
		header("Location: ../AccountCreation.php?Please enter information");
	}
	
	
?>