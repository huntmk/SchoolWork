<?php
	if(isset($_POST['departure']))
	{
		$departure = $_POST['departure'];
		
		session_start();
		$_SESSION['departID'] = $departure;
		
		header("Location: ../ReturnFlightPage.php");
		
	}
	else 
	{
		header("Location: ../DepartFlightPage.php");
		echo '<script>alert("Please enter all information!")</script>';
		
	}

?>