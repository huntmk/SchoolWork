<?php
	include_once 'connect.php';
	if(!empty($_POST['username']) || !empty($_POST['password']))
	{
		
		$user = $_POST['username'];
		$password = $_POST['password'];
		
		$sql = "SELECT email, password FROM Customer WHERE email = '".$user."' AND  password = '".$password."'";
		
		$result = mysqli_query($con,$sql);
		 
		if(mysqli_num_rows($result) == 1)
		{
			session_start();
			$_SESSION['email'] = $user;
			header("Location: ../BillingPage.php?login=success");
		}
		else
		{
			header("Location: ../LoginPage.php?username and password don't match");		
		}
		
	}
	else
	{
		header("Location: ../LoginPage.php?username and passsword aren't set");
	}
	
	
?>