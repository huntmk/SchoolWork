<?php
	if (isset($_POST['noReturn']) || !isset($_POST['return_flight']))
	{
		session_start();
		$_SESSION['rAvail'] = -1;
		$_SESSION['returnID'] = "NULL";
		
	}
	else {
	$return_flight = $_POST['return_flight'];
	
	$_SESSION['returnID'] = $return_flight;
	
	}
	
	header("Location: ../TicketQuantityPage.php");
	

?>