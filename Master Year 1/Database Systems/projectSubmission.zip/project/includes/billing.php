<?php
	include_once 'connect.php';

	if(!empty($_POST['cardnum']))
	{
		$cardnum = $_POST['cardnum'];
		$expMonth = $_POST['expMonth'];
		$expYear = $_POST['expYear'];
		
		session_start();
		$_SESSION['cardnum'] = $cardnum;
		$_SESSION['expMonth'] = $expMonth;
		$_SESSION['expYear'] = $expYear;

		
		header("Location: ../ConfirmPage.php");
		
	}
	
	else
	{
		header("Location: ../BillingPage.php?selection=failed - fill out all information below");
	}
	

	
?>