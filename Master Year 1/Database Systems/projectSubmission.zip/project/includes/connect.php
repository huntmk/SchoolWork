<?php

	$host = "localhost";
	$dbusername = "root";
	$dbpassword = "#91Rodman";
	$dbname = "Project";

	$con = mysqli_connect($host,$dbusername,$dbpassword,$dbname);

	
?>