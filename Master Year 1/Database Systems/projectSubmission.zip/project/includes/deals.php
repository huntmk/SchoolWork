<?php
	if(isset($_POST['deals']))
	{
		$departure = $_POST['deals'];
		
		session_start();
		$_SESSION['departID'] = $departure;
		
		header("Location: ../ReturnFlightPage.php");
		
	}
	else 
	{
		header("Location: ../GreatDeals.php");
		echo '<script>alert("Please enter all information!")</script>';
		
	}

?>