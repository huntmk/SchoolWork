<?php
	include_once 'connect.php';

	session_start();
	
	//VAriables
	$departID = $_SESSION['departID'];
	$returnID = $_SESSION['returnID'];
	$ticketQty = $_SESSION['ticket'];
	$cardnum = $_SESSION['cardnum'];
	$expMonth = $_SESSION['expMonth'];
	$expYear = $_SESSION['expYear'];
	

	
	$sql_one = "Select * from Customer WHERE email = '".$_SESSION['email']."'";
	
	$result_one = mysqli_query($con,$sql_one);
	
	while($d= mysqli_fetch_assoc($result_one))
	{
		$_SESSION['cid'] = $d['cid'];
	}
	$cid = $_SESSION['cid'];
	
	//insert into database
	$sql = "INSERT INTO Reservation (cid,dfid,rfid,qty,cardnum,cardmonth,cardyear)
		VALUES ($cid,$departID,$returnID,$ticketQty,
        $cardnum, $expMonth, $expYear)";
		
	
	if (mysqli_query($con, $sql))
		{
			//Then send an email
			
			("Location: ../SubmitPage.php?confirmation=success");
        } 
		else 
		{
		   echo "Error: " . $sql . "" . mysqli_error($con);
		}

	
	
	
	
	
?>