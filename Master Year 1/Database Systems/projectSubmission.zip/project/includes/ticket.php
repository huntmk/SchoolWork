<?php
	session_start();

	if ($_SESSION['dAvail'] >= $_POST['quantity'] && ($_SESSION['rAvail'] >= $_POST['quantity'] || $_SESSION['rAvail'] == -1))
	{
		
		$ticket_quantity = $_POST['quantity'];
		
		$_SESSION['ticket'] = $ticket_quantity;

		header("Location: ../LoginPage.php");
	}
	else
	{
		header("Location: ../TicketQuantityPage.php?choose flight with available tickets or change ticket number");
	}
	
	

?>