<?php

	if(isset($_GET['origin'], $_GET['dest']) && !empty($_GET['depart']))
	{
		
		$origin = $_GET['origin'];
		$dest = $_GET['dest'];
		$depart = $_GET['depart'];
		$return = $_GET['return'];
		
		session_start();
		$_SESSION['origin'] = $origin;
		$_SESSION['dest'] = $dest;
		$_SESSION['depart'] = $depart;
		$_SESSION['return'] = $return;

		
		header("Location: ../DepartFlightPage.php");
		
	}
	else 
	{
		header("Location: ../HomePage.php?error");

	}

?>