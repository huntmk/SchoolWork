<!DOCTYPE html>
<?php
	include_once 'includes/connect.php';
?>
<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	<h1 id="header"> Confirmation Page</h1>
		<div id="confirm_page">
			<ul id="naviagtion">
				<li><a href ="./HomePage.php">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>
			
			<form method="POST" action ="includes/confirm.php">
				<p> Flight information below: <br> 
				<?php
					session_start();
					$email = $_SESSION['email'];
					$sql = "SELECT * FROM Customer WHERE email = '".$_SESSION['email']."'";
					$result = mysqli_query($con,$sql);
										
					while($d= mysqli_fetch_assoc($result)){
						echo "Name: " .$d['c_name']. " Email: " .$d['email']. " Address: " .$d['address']. "<br>";
					}
					
					$sql_two = "SELECT fnumber, fdate, ftime, class, price FROM Flight WHERE fid = '".$_SESSION['departID']."'";
					$result_two = mysqli_query($con,$sql_two);
					
					echo "Departure flight: ";
					while($e= mysqli_fetch_assoc($result_two))
					{
						echo "Flight Number: " .$e['fnumber']. " Flight Date: " .$e['fdate']. " Flight Time: " .$e['ftime'].
						" Class: ".$e['class']. " Price: " .$e['price']. "<br>";
					}
					
					echo "Return flight (if entered): ";
					$sql_three = "SELECT fnumber, fdate, ftime, class, price FROM Flight WHERE fid = '".$_SESSION['returnID']."'";
					$result_three = mysqli_query($con,$sql_three);
					
					while($g = mysqli_fetch_assoc($result_three))
					{
						echo "Flight Number: " .$g['fnumber']. " Flight Date: " .$g['fdate']. " Flight Time: " .$g['ftime'].
						" Class: ".$g['class']. " Price: " .$g['price']. "<br>";
					}
					
			
					
				?>
				<br><br>
				
				This is the the flight information below. Select Confirm to place flight(s).
				</p>
				 
				
				
				<input type="submit" value ="Confirm Flight(s)">
			</form>
			
		</div>
	</body>
</html>