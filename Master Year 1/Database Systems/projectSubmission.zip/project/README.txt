README.txt
To run my website on your computer:

1.) The DBMS that I used was MYSQL server. Using this I created the database, the tables, and the triggers using the script.
This is all contained in the "initializaiton.sql" file. It can be using MYSQL or in Notepad. Also I used XAMPP to run on my system which be easy. Look at the link for how to set this up. https://www.edureka.co/blog/how-to-run-a-php-program-in-xampp/
	a)I downloaded XAMPP to run a local server using apache.
	b)Used MySQL to create tables and triggers and initialize the tables below.
	c)Make sure ports are are correlated in XAMPP
	d)The folder "project" folder needs to be in (C:/Program Files/XAMPP/htdocs)

	

2.) Next is putting values in the Flight and City Tables
In my Example I had:

City:	cityId	title	state
	1	Chicago	IL
	2	Houston	TX
	

Flight: 	fid	fnumber	fdate		ftime		price		capacity	class		available	orig		dest
		1	10	2021-5-25	12:00:00	100		100		1		2			1		2
		2 	20	2021-5-27	12:00:00	100		100		1		2			2		1
		3 	30	2021-6-1	12:00:00	50		100		1		3			1		2

3) Then once the there are some values for both of those tables, then we can start the website.
	The file that is submitted inside has the page files and then there the "includes" folder which has multiple files used for form submissions.
	Also to note before starting the website, navigate to the "connect.php" inside the "includes" folder to configure the settings to accomdate the settings for your local server.
	Note to also keep the file structure the same (as in folder "project") as the website call the form submission files and goes to the other pages via the location they are currently in.
	
4)Run the "HomePage.php" to start working throught the website. (This is how the website address looked when using XAMPP Apache server: http://localhost/project/homepage.php)
Next your brought to the Depart and Flight web pages where you select the flight from drop down menu and then to the Ticket Quantity page.
You are then prompted to login or create an account. Once you create an account, your brought to the login page to use login information that was just created.
Then you are brought to the billing page to enter information. Last, you are the confirmation page to review the information.
Once it is submitted you are supposed to receive an email but due to this being done on a local server, this currently can't be done.

5)
You can then start over or view the other pages in the menu for additional information.
	
	
	