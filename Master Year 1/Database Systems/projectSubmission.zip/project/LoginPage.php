<!DOCTYPE html>
<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	<h1 id="header"> Airlines Website - Login Page</h1>
		<div id="ticket_quantity">
			<ul id="naviagtion">
				<li><a href ="./HomePage.php">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>
			<form method="POST" action ="includes/login.php">
				<label> Username(email):
				<input type="text" name="username">
				</br></br>
				
				<label>Password:
				<input type="password" name="password">
				</br></br>
				
				<input type="submit">
			</form>
			
			<form action = "">
				<p>Create Account <p>
				<button type="submit" formaction="AccountCreation.php">Create Account
			</form>
			
		</div>	
	</body>
</html>	
				
				