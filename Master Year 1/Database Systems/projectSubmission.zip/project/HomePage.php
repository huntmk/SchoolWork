<!DOCTYPE html>
<?php
	include_once 'includes/connect.php';
?>

<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	
	<h1 id="header"> Airlines Website</h1>
		<div id="home">
			<ul id="naviagtion">
				<li><a href ="#home">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>

				
		<h2> Welcome to our Airlines Website </h2>
		
		<!--
			May need to change method from 'post' to 'get' because I am not changing anything but getting information from database
		-->
	
		<form method="GET" action= "includes/first_origin_dest.php">
			<p>Origin (city) </p>
			
			<select name ="origin" id="originCity">
			<?php
				$sql = "SELECT * FROM City";
				$result = mysqli_query($con,$sql);
				while ( $d=mysqli_fetch_assoc($result)) {
					echo "<option value= ".$d['cityid'].">" .$d['title'].  "</option>";
				}
			?>
			</select>
			
			<p>Destination(city)</p>
			
			<select name ="dest" id="destCit">
			<?php
				$sql = "SELECT * FROM City";
				$result = mysqli_query($con,$sql);
				while ( $d=mysqli_fetch_assoc($result)) {
					echo "<option value= ".$d['cityid'].">" .$d['title'].  "</option>";
				}
			?>
		
			</select>
			
			
		
			<p>Departure (date)
			<input type="date" name="depart" min = 
				<?php 
					echo date('Y-m-d')
				?>
			>			
			</p>
		
			<p>Return (date) - Optional
			<input type="date" name="return" min = 
				<?php 
					echo date('Y-m-d')
				?>
			
			</p>
			<br/><br/>
			
			<input type="submit"/>
		</form>
		
	</body>			
	</html>			
			