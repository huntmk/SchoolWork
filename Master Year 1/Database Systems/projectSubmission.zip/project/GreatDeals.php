<!DOCTYPE html>
<?php
	include_once 'includes/connect.php';
?>

<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	<h1 id="header"> Airlines Website - Select Departure Flight Page</h1>
		<div id="depart">
			<ul id="naviagtion">
				<li><a href ="./HomePage.php">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>
<!--
	Figure out action to show output of query needed to display departures 
-->

		<form method="POST" action="includes/deals.php">
			<p> Select Departure Flight </p>
				
			<select name="deals">
			<?php
				//query
				
				$sql="SELECT * FROM Flight where price < 100";
				$result = mysqli_query($con,$sql);
				session_start();
				while ($d= mysqli_fetch_assoc($result)){
					
					$sql_one ="Select * FROM City where cityid = '".$d['orig']."'";
					$result_one  = mysqli_query($con,$sql_one);
					
					$sql_two ="Select * FROM City where cityid = '".$d['dest']."'";
					$result_two  = mysqli_query($con,$sql_two);
					
					
					echo "<option value = " .$d['fid']. ">  Flight Number: " .$d['fnumber']. ", Flight Date: " .$d['fdate']. ", Flight Time: " .$d['ftime'].
							", Class: ".$d['class']. " , Price: " .$d['price'].  ", Origin: ";
					
					while ($e = mysqli_fetch_assoc($result_one))
					{
						echo $e['title']. ", Destination: ";
					}
					
					while ($g = mysqli_fetch_assoc($result_two))
					{
						echo $g['title']. "</option>" ;
					}
				}
				
					
			?>			
			</select>
			<br/><br/>
					
				
				<input type="submit"/>

		</form>