<!DOCTYPE html>
<?php
	include_once 'includes/connect.php';
?>
<html>
	<head>
		<title>Airlines</title>
	</head>
	<body>
	<h1 id="header"> Airlines Website - Select Return Flight Page</h1>
		<div id="return">
			<ul id="naviagtion">
				<li><a href ="./HomePage.php">Start Over</a></li>
				<li><a href ="./GreatDeals.php">Great Deals</a></li>
				<li><a href ="./HelpPage.html">Help</a></li>
				<li><a href ="./ContactPage.html">Contact</a></li>
			</ul>
<!--
	Figure out action to show output of query needed to display departures 
-->

		<form method= "POST" action="includes/return.php">
			<p> Select Return Flight (Optional)</p>				

			<select name="return_flight"> 
				
				<!-- figure out how to show query in radio buttons -->
				<?php
					//query
					$sql="SELECT * FROM Flight";
					$result = mysqli_query($con,$sql);
					$resultChk = mysqli_num_rows($result);
					session_start();				
					while ($d= mysqli_fetch_assoc($result)){
						if ($_SESSION['origin'] == $d['dest'] && $d['orig'] == $_SESSION['dest'] && $_SESSION['return'] == $d['fdate'] && $d['available'] > 0 ){
							//get number of available tickets
							$_SESSION['rAvail'] = $d['available'];
							echo "<option value = " .$d['fid']. "> Flight Number: " .$d['fnumber']. ", Flight Date: " .$d['fdate']. ", Flight Time: " .$d['ftime'].
						", Class: ".$d['class']. ", Price: " .$d['price']. ", Available: ".$d['available'].  "</option>";
						}
					}	
				?>		
				</select>
				<br/>
				<input type ="radio" id="noReturn" name="noReturn" value="0">
				<label for="noReturn">No Return Option </label>
				<br/>
				<input type="submit"/>

		</form>